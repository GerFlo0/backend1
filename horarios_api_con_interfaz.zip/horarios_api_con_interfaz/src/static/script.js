$(document).ready(function () {
    // Mostrar u ocultar el formulario
    $('#mostrarFormBtn').click(function () {
        $('#formHorario').toggle();
    });

    // Cargar horarios
    function getHorarios() {
        $.get('/api/horarios/', function (data) {
            $('#horariosList').empty();
            if (data.length > 0) {
                data.forEach(function (horario) {
                    $('#horariosList').append(`
                        <div class="alert alert-info" role="alert">
                            <strong>Sección:</strong> ${horario.seccion} <br>
                            <strong>Hora Inicio:</strong> ${horario.hora_inicio} <br>
                            <strong>Hora Fin:</strong> ${horario.hora_fin} <br>
                            <strong>Estado:</strong> ${horario.estado ? 'Activo' : 'Inactivo'} <br>
                            <button class="btn btn-warning btn-sm updateBtn" data-id="${horario.id}">Actualizar</button>
                            <button class="btn btn-danger btn-sm deleteBtn" data-id="${horario.id}">Eliminar</button>
                        </div>
                    `);
                });
            } else {
                $('#horariosList').append('<p>No hay horarios disponibles.</p>');
            }
        });
    }

    getHorarios();

    // Guardar horario
    $('#horarioForm').submit(function (e) {
        e.preventDefault();

        const nuevoHorario = {
            seccion: $('#seccion').val(),
            hora_inicio: $('#hora_inicio').val(),
            hora_fin: $('#hora_fin').val(),
            estado: $('#estado').val() === "true",
            fecha_creacion: $('#fecha_creacion').val(),
            fecha_modificacion: $('#fecha_modificacion').val()
        };

        $.ajax({
            url: '/api/horarios/',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(nuevoHorario),
            success: function () {
                alert('Horario guardado correctamente');
                $('#horarioForm')[0].reset();
                $('#formHorario').hide();
                getHorarios();
            },
            error: function () {
                alert('Error al guardar el horario');
            }
        });
    });

    // Eliminar horario
    $(document).on('click', '.deleteBtn', function () {
        const id = $(this).data('id');
        $.ajax({
            url: `/api/horarios/${id}`,
            type: 'DELETE',
            success: function () {
                alert('Horario eliminado');
                getHorarios();
            },
            error: function () {
                alert('Error al eliminar horario');
            }
        });
    });

    // Obtener datos de API filtrados por sección
    $('#obtenerDatosBtn').click(function () {
        const seccion = $('#filtroSeccion').val();
        let url = '/api/horarios/';
        if (seccion !== 'todos') {
            url += seccion;
        }

        $.get(url, function (data) {
            $('#apiData').empty();

            if (data.length > 0) {
                data.forEach(function (item) {
                    $('#apiData').append(`
                        <div class="card mb-3">
                            <div class="card-header">
                                <strong>Sección:</strong> ${item.seccion}
                            </div>
                            <div class="card-body">
                                <p><strong>Hora Inicio:</strong> ${item.hora_inicio}</p>
                                <p><strong>Hora Fin:</strong> ${item.hora_fin}</p>
                                <p><strong>Estado:</strong> ${item.estado === 't' ? 'Activo' : 'Inactivo'}</p>
                                <p><strong>Creación:</strong> ${item.fecha_creacion}</p>
                                <p><strong>Modificación:</strong> ${item.fecha_modificacion}</p>
                            </div>
                        </div>
                    `);
                });
            } else {
                $('#apiData').append('<p>No hay datos disponibles para esta sección.</p>');
            }
        });
    });
});